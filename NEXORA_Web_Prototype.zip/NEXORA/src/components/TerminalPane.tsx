import React, { useState } from 'react';
import { Terminal as TermIcon, X, Plus, Trash2, ChevronUp, SplitSquareHorizontal, LayoutPanelTop } from 'lucide-react';

export const TerminalPane = () => {
  const [isMaximized, setIsMaximized] = useState(false);

  return (
    <div className={`bg-[#1e1e1e] border-t border-[#2b2b2b] flex flex-col shrink-0 font-mono text-[13px] relative z-10 transition-all ${isMaximized ? 'h-full absolute inset-0' : 'h-64'}`}>
      
      {/* Terminal Header Tabs */}
      <div className="flex bg-[#181818] border-b border-[#2b2b2b] px-4 font-sans text-[11px] tracking-wide uppercase shrink-0">
        <div className="flex items-center gap-5 text-[#858585]">
          <span className="py-2.5 cursor-pointer hover:text-white transition-colors">Problems <span className="bg-[#3c3c3c] px-1.5 rounded-full text-white ml-1">0</span></span>
          <span className="py-2.5 cursor-pointer hover:text-white transition-colors">Output</span>
          <span className="py-2.5 cursor-pointer hover:text-white transition-colors">Debug Console</span>
          <span className="py-2.5 text-white border-b-2 border-blue-500 cursor-pointer">Terminal</span>
          <span className="py-2.5 cursor-pointer hover:text-white transition-colors">Ports</span>
        </div>
        <div className="flex-1"></div>
        <div className="flex items-center gap-3 text-[#858585]">
          <div className="flex items-center gap-1.5 bg-[#2a2d2e] px-2 py-0.5 rounded-md text-[#cccccc] cursor-pointer hover:bg-[#3c3c3c] hover:text-white transition-colors text-xs lowercase border border-[#3c3c3c]">
            <TermIcon size={12} />
            <span>bash</span>
          </div>
          <div className="flex items-center gap-2 ml-2">
            <Plus size={14} className="hover:text-white cursor-pointer transition-colors" title="New Terminal" />
            <SplitSquareHorizontal size={14} className="hover:text-white cursor-pointer transition-colors" title="Split Terminal" />
            <Trash2 size={14} className="hover:text-white cursor-pointer transition-colors" title="Kill Terminal" />
            <div className="w-px h-4 bg-[#3c3c3c] mx-1"></div>
            <LayoutPanelTop 
              size={14} 
              className="hover:text-white cursor-pointer transition-colors" 
              title={isMaximized ? "Restore Terminal Size" : "Maximize Terminal"}
              onClick={() => setIsMaximized(!isMaximized)}
            />
            <X size={14} className="hover:text-white cursor-pointer transition-colors" title="Close Panel" />
          </div>
        </div>
      </div>

      {/* Terminal Content */}
      <div className="flex-1 p-4 overflow-y-auto text-[#cccccc] leading-relaxed custom-scrollbar bg-[#1e1e1e]">
        <div className="mb-2">
          <div className="flex gap-2">
            <span className="text-green-400 font-bold">user@nexora</span><span className="text-white">:</span><span className="text-blue-400 font-bold">~/NEXORA</span><span className="text-white">$</span> <span className="text-white">npm run dev</span>
          </div>
          <div className="mt-1">
            <span className="text-[#4ec9b0]">VITE</span> v5.4.21  ready in <span className="font-bold">687 ms</span><br/><br/>
            ➜  Local:   <a href="#" className="text-[#569cd6] hover:underline">http://localhost:5173/</a><br/>
            ➜  Network: <a href="#" className="text-[#569cd6] hover:underline">http://192.0.0.4:5173/</a><br/>
            ➜  press h + enter to show help
          </div>
        </div>
        <div className="flex gap-2">
          <span className="text-green-400 font-bold">user@nexora</span><span className="text-white">:</span><span className="text-blue-400 font-bold">~/NEXORA</span><span className="text-white">$</span> <span className="animate-pulse bg-white w-2 h-4 inline-block translate-y-1"></span>
        </div>
      </div>
    </div>
  );
}
