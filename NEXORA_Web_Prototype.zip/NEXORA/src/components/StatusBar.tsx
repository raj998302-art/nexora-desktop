import React from 'react';
import { GitBranch, XCircle, AlertTriangle, Radio } from 'lucide-react';

export const StatusBar = () => {
  return (
    <div className="h-6 bg-[#007acc] text-white flex items-center justify-between px-3 text-[11px] font-sans shrink-0 select-none z-20">
      <div className="flex items-center gap-4 h-full">
        <div className="flex items-center gap-1.5 hover:bg-white/10 px-2 h-full cursor-pointer transition-colors">
          <GitBranch size={12} />
          <span>main*</span>
        </div>
        <div className="flex items-center gap-3 hover:bg-white/10 px-2 h-full cursor-pointer transition-colors">
          <div className="flex items-center gap-1"><XCircle size={12} /> 0</div>
          <div className="flex items-center gap-1"><AlertTriangle size={12} /> 0</div>
        </div>
      </div>
      
      <div className="flex items-center gap-2 h-full">
        <div className="flex items-center gap-1.5 hover:bg-white/10 px-2 h-full cursor-pointer transition-colors">
          <Radio size={12} className="animate-pulse" />
          <span>Port: 5173</span>
        </div>
        <div className="hover:bg-white/10 px-2 h-full flex items-center cursor-pointer transition-colors">UTF-8</div>
        <div className="hover:bg-white/10 px-2 h-full flex items-center cursor-pointer transition-colors">TypeScript React</div>
        <div className="hover:bg-white/10 px-2 h-full flex items-center cursor-pointer transition-colors">Prettier</div>
      </div>
    </div>
  );
}
