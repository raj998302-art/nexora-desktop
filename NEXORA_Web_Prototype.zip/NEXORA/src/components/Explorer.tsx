import React, { useState } from 'react';
import { ChevronRight, ChevronDown, FileJson, FileCode2, FileImage, FileType2, Folder, FolderOpen, FileText, FilePlus, FolderPlus, RefreshCcw, CollapseAll, CopyMinus } from 'lucide-react';
import { cn } from '../utils/cn';

export const Explorer = () => {
  return (
    <div className="flex flex-col h-full font-sans">
      <div className="flex items-center justify-between px-4 py-2 border-b border-[#2b2b2b] bg-[#181818] shrink-0">
        <span className="text-[11px] font-bold text-[#cccccc] uppercase tracking-wider">NEXORA</span>
        <div className="flex items-center gap-2 text-[#858585]">
          <FilePlus size={14} className="hover:text-white cursor-pointer transition-colors" title="New File" />
          <FolderPlus size={14} className="hover:text-white cursor-pointer transition-colors" title="New Folder" />
          <RefreshCcw size={13} className="hover:text-white cursor-pointer transition-colors" title="Refresh" />
          <CopyMinus size={14} className="hover:text-white cursor-pointer transition-colors" title="Collapse Folders" />
        </div>
      </div>
      
      <div className="overflow-y-auto flex-1 custom-scrollbar py-2">
        <FolderItem name="src" open={true}>
          <FolderItem name="components" open={true}>
            <FileItem name="App.tsx" active ext="tsx" />
            <FileItem name="ActivityBar.tsx" ext="tsx" />
            <FileItem name="AiChat.tsx" ext="tsx" />
            <FileItem name="HomeDashboard.tsx" ext="tsx" />
            <FileItem name="LeftPanel.tsx" ext="tsx" />
            <FileItem name="SettingsView.tsx" ext="tsx" />
          </FolderItem>
          <FolderItem name="utils" open={false}>
            <FileItem name="cn.ts" ext="ts" />
          </FolderItem>
          <FileItem name="main.tsx" ext="tsx" />
          <FileItem name="index.css" ext="css" />
          <FileItem name="store.ts" ext="ts" />
        </FolderItem>
        <FolderItem name="public" open={false}>
          <FileItem name="vite.svg" ext="svg" />
        </FolderItem>
        <FileItem name="package.json" ext="json" />
        <FileItem name="tailwind.config.js" ext="js" />
        <FileItem name="tsconfig.json" ext="json" />
        <FileItem name="README.md" ext="md" />
      </div>
    </div>
  );
}

const FolderItem = ({ name, children, open = false }: { name: string, children: React.ReactNode, open?: boolean }) => {
  const [isOpen, setIsOpen] = useState(open);
  
  return (
    <div>
      <div 
        className="flex items-center gap-1.5 px-4 py-1 hover:bg-[#2a2d2e] cursor-pointer text-[13px] text-[#cccccc] transition-colors"
        onClick={() => setIsOpen(!isOpen)}
        style={{ paddingLeft: '1rem' }}
      >
        <div className="flex items-center gap-1">
          {isOpen ? <ChevronDown size={14} className="text-[#858585]" /> : <ChevronRight size={14} className="text-[#858585]" />}
          {isOpen ? <FolderOpen size={14} className="text-[#dcb67a]" /> : <Folder size={14} className="text-[#dcb67a]" />}
        </div>
        <span>{name}</span>
      </div>
      {isOpen && <div className="space-y-[1px] border-l border-[#2b2b2b] ml-6">{children}</div>}
    </div>
  );
}

const FileItem = ({ name, active = false, ext = '' }: { name: string, active?: boolean, ext?: string }) => {
  let Icon = FileCode2;
  let color = 'text-[#519aba]';

  if (ext === 'json') {
    Icon = FileJson;
    color = 'text-[#cbcb41]';
  } else if (ext === 'js' || ext === 'ts') {
    Icon = FileType2;
    color = 'text-[#519aba]';
  } else if (ext === 'tsx' || ext === 'jsx') {
    Icon = FileCode2;
    color = 'text-[#519aba]';
  } else if (ext === 'css') {
    Icon = FileCode2;
    color = 'text-[#51b6c8]';
  } else if (ext === 'md') {
    Icon = FileText;
    color = 'text-[#4ea1df]';
  } else if (ext === 'svg') {
    Icon = FileImage;
    color = 'text-[#b072a9]';
  }

  return (
    <div 
      className={cn(
        "flex items-center gap-2 py-1 cursor-pointer text-[13px] transition-colors",
        active ? "bg-[#37373d] text-white" : "hover:bg-[#2a2d2e] text-[#cccccc]"
      )}
      style={{ paddingLeft: '1rem' }}
    >
      <Icon size={14} className={color} />
      <span className={active ? color : ""}>{name}</span>
    </div>
  );
};
