import React, { useState } from 'react';
import { Send, Mic, Paperclip, Sparkles, MoreHorizontal, Maximize2, ChevronDown, Check, Globe, Brain, Zap, AtSign, FileCode, FolderGit2, BookOpen, MessageSquare, History } from 'lucide-react';
import { cn } from '../utils/cn';
import { motion, AnimatePresence } from 'framer-motion';

type AiMode = 'Normal' | 'Agent' | 'Architect';
type ThinkingLevel = 'Normal' | 'High' | 'Max' | 'Ultra';

export const AiChat = () => {
  const [mode, setMode] = useState<AiMode>('Agent');
  const [showModeDropdown, setShowModeDropdown] = useState(false);
  
  const [thinkingLevel, setThinkingLevel] = useState<ThinkingLevel>('Normal');
  const [showThinkingDropdown, setShowThinkingDropdown] = useState(false);
  
  const [webSearch, setWebSearch] = useState(false);
  const [showContext, setShowContext] = useState(false);

  return (
    <div className="flex flex-col h-full bg-[#1e1e1e] relative font-sans text-sm">
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-[#2b2b2b] shrink-0 text-[#cccccc] bg-[#181818]">
        <div className="flex items-center gap-2 font-semibold">
          <Sparkles size={16} className="text-blue-400" />
          <span>Composer</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 cursor-pointer hover:text-white text-xs bg-[#2a2d2e] px-2 py-1 rounded border border-[#3c3c3c]">
            <span>Claude 3.5 Sonnet</span>
            <ChevronDown size={12} />
          </div>
          <History size={14} className="cursor-pointer hover:text-white" title="Chat History" />
          <Maximize2 size={14} className="cursor-pointer hover:text-white" />
          <MoreHorizontal size={14} className="cursor-pointer hover:text-white" />
        </div>
      </div>

      {/* Chat History */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar bg-[#1e1e1e]">
        {/* User Message */}
        <div className="flex flex-col gap-1.5">
          <div className="font-semibold text-[#cccccc] flex items-center justify-between">
            <span>You</span>
          </div>
          <div className="text-[#cccccc] bg-[#2a2d2e] p-3 rounded-lg border border-[#3c3c3c]">
            Make sure all IDE features like History, Minimap, Lightbulb, and dropdowns are perfectly added!
          </div>
        </div>

        {/* AI Message */}
        <div className="flex flex-col gap-1.5">
          <div className="font-semibold text-blue-400 flex items-center gap-1.5">
            <Sparkles size={14} /> NEXORA Agent
          </div>
          <div className="text-[#cccccc] p-3 rounded-lg border border-[#3c3c3c] bg-[#1e1e1e]">
            <p>Done! Here are the newest additions:</p>
            <ul className="list-disc pl-4 mt-2 space-y-1 text-[13px]">
              <li><strong>History:</strong> Added the History icon at the top of the AI Chat.</li>
              <li><strong>Minimap:</strong> Added a realistic syntax-colored minimap to the right of the Code Editor.</li>
              <li><strong>Quick Fix (Lightbulb):</strong> Added an interactive lightbulb that appears when you hover over the code!</li>
              <li><strong>Thinking Dropdown:</strong> Upgraded the Brain button to include Normal, High, Max, and Ultra reasoning levels.</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Input / Composer Area */}
      <div className="p-4 shrink-0 bg-[#1e1e1e] relative">
        <AnimatePresence>
          {showContext && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              transition={{ duration: 0.15 }}
              className="absolute bottom-[100%] left-4 right-4 mb-2 bg-[#252526] border border-[#3c3c3c] rounded-lg shadow-2xl p-1 z-50 flex flex-col"
            >
              <div className="px-3 py-1.5 text-xs font-semibold text-[#858585] border-b border-[#2b2b2b] mb-1">Add Context</div>
              <ContextOption icon={<FileCode size={14}/>} title="Files" shortcut="Search workspace files" />
              <ContextOption icon={<FolderGit2 size={14}/>} title="Codebase" shortcut="Index entire codebase" />
              <ContextOption icon={<Globe size={14}/>} title="Web" shortcut="Search the internet" />
              <ContextOption icon={<Sparkles size={14}/>} title="Upload Skill" shortcut="Upload a custom skill" />
            </motion.div>
          )}
        </AnimatePresence>

        <div className="relative flex flex-col bg-[#2a2d2e] border border-[#3c3c3c] rounded-xl shadow-lg focus-within:border-[#555] transition-colors overflow-visible">
          
          <textarea 
            placeholder={mode === 'Agent' ? "Tell NEXORA what to build or execute..." : "Ask a question..."}
            className="w-full bg-transparent pt-4 px-3 text-[13px] text-white focus:outline-none placeholder:text-[#858585] resize-none h-20 custom-scrollbar"
          />
          
          {/* Bottom Actions inside Input */}
          <div className="flex justify-between items-center px-2 pb-2 pt-1 border-t border-[#3c3c3c]/50">
            <div className="flex items-center gap-0.5">
              
              {/* Mode Dropdown */}
              <div className="relative">
                <button 
                  onClick={() => { setShowModeDropdown(!showModeDropdown); setShowThinkingDropdown(false); setShowContext(false); }}
                  className={cn(
                    "flex items-center gap-1 px-2 py-1 rounded text-[11px] font-medium transition-colors border mr-1",
                    mode === 'Agent' || mode === 'Architect' ? "bg-blue-500/10 border-blue-500/30 text-blue-400" : "bg-transparent border-transparent text-[#858585] hover:bg-[#333] hover:text-[#cccccc]"
                  )}
                >
                  {mode === 'Normal' && <MessageSquare size={12} />}
                  {mode === 'Agent' && <Zap size={12} />}
                  {mode === 'Architect' && <Check size={12} />}
                  <span>{mode}</span>
                  <ChevronDown size={10} className="opacity-70 ml-0.5" />
                </button>
                
                <AnimatePresence>
                  {showModeDropdown && (
                    <motion.div 
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 5 }}
                      transition={{ duration: 0.15 }}
                      className="absolute bottom-full left-0 mb-2 w-40 bg-[#252526] border border-[#3c3c3c] rounded-lg shadow-xl p-1 z-50 flex flex-col"
                    >
                      <ModeOption icon={<MessageSquare size={12} />} title="Normal" active={mode === 'Normal'} onClick={() => { setMode('Normal'); setShowModeDropdown(false); }} />
                      <ModeOption icon={<Zap size={12} />} title="Agent" active={mode === 'Agent'} onClick={() => { setMode('Agent'); setShowModeDropdown(false); }} />
                      <ModeOption icon={<Check size={12} />} title="Architect" active={mode === 'Architect'} onClick={() => { setMode('Architect'); setShowModeDropdown(false); }} />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <button 
                onClick={() => { setShowContext(!showContext); setShowModeDropdown(false); setShowThinkingDropdown(false); }}
                className="flex items-center justify-center p-1.5 text-[#858585] hover:text-white transition rounded hover:bg-[#333]"
                title="Add Context (@)"
              >
                <AtSign size={14} />
              </button>

              {/* Thinking Dropdown */}
              <div className="relative">
                <button 
                  onClick={() => { setShowThinkingDropdown(!showThinkingDropdown); setShowModeDropdown(false); setShowContext(false); }}
                  className={cn(
                    "flex items-center gap-1 px-2 py-1 rounded text-[11px] font-medium transition-colors border mx-1",
                    thinkingLevel !== 'Normal' ? "bg-purple-500/10 border-purple-500/30 text-purple-400" : "bg-transparent border-transparent text-[#858585] hover:bg-[#333] hover:text-[#cccccc]"
                  )}
                  title="Deep Reasoning Mode"
                >
                  <Brain size={12} />
                  {thinkingLevel !== 'Normal' && <span>{thinkingLevel}</span>}
                  <ChevronDown size={10} className="opacity-70 ml-0.5" />
                </button>

                <AnimatePresence>
                  {showThinkingDropdown && (
                    <motion.div 
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 5 }}
                      transition={{ duration: 0.15 }}
                      className="absolute bottom-full left-0 mb-2 w-48 bg-[#252526] border border-[#3c3c3c] rounded-lg shadow-xl p-1 z-50 flex flex-col"
                    >
                      <ModeOption icon={<Brain size={12} />} title="Normal" desc="Standard reasoning" active={thinkingLevel === 'Normal'} onClick={() => { setThinkingLevel('Normal'); setShowThinkingDropdown(false); }} />
                      <ModeOption icon={<Brain size={12} />} title="High" desc="Extended CoT" active={thinkingLevel === 'High'} onClick={() => { setThinkingLevel('High'); setShowThinkingDropdown(false); }} />
                      <ModeOption icon={<Brain size={12} />} title="Max" desc="Deep problem solving" active={thinkingLevel === 'Max'} onClick={() => { setThinkingLevel('Max'); setShowThinkingDropdown(false); }} />
                      <ModeOption icon={<Brain size={12} />} title="Ultra" desc="Maximum compute" active={thinkingLevel === 'Ultra'} onClick={() => { setThinkingLevel('Ultra'); setShowThinkingDropdown(false); }} />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <button 
                onClick={() => setWebSearch(!webSearch)}
                className={cn("flex items-center gap-1 p-1.5 rounded transition-colors", webSearch ? "bg-green-500/20 text-green-400" : "text-[#858585] hover:bg-[#333] hover:text-[#cccccc]")}
                title="Search the web"
              >
                <Globe size={14} />
              </button>
            </div>
            
            <button className="flex items-center justify-center p-1.5 text-white transition rounded-md bg-blue-600 hover:bg-blue-500 mr-1">
              <Send size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

const ContextOption = ({ icon, title, shortcut }: { icon: React.ReactNode, title: string, shortcut: string }) => (
  <div className="flex items-center justify-between px-3 py-2 hover:bg-[#37373d] rounded cursor-pointer group">
    <div className="flex items-center gap-3">
      <span className="text-[#858585] group-hover:text-white">{icon}</span>
      <span className="text-sm text-[#cccccc] group-hover:text-white">{title}</span>
    </div>
    <span className="text-[11px] text-[#555] group-hover:text-[#858585]">{shortcut}</span>
  </div>
);

const ModeOption = ({ icon, title, desc, active, onClick }: { icon: React.ReactNode, title: string, desc?: string, active: boolean, onClick: () => void }) => (
  <div 
    onClick={onClick}
    className={cn(
      "flex flex-col px-2 py-1.5 rounded-md cursor-pointer transition-colors",
      active ? "bg-blue-500/10" : "hover:bg-[#37373d]"
    )}
  >
    <div className={cn("flex items-center gap-2 text-[12px] font-medium", active ? "text-blue-400" : "text-[#cccccc]")}>
      {icon}
      <span>{title}</span>
    </div>
    {desc && <span className="text-[10px] text-[#858585] ml-6 mt-0.5">{desc}</span>}
  </div>
);
