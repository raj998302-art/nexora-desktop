import React from 'react';
import { Search, Download, Star, Package } from 'lucide-react';

export const ExtensionPanel = () => {
  return (
    <div className="flex flex-col h-full font-sans">
      <div className="p-2">
        <div className="relative flex items-center border border-[#3c3c3c] bg-[#2a2d2e] rounded focus-within:border-blue-500 transition-colors">
          <input 
            type="text" 
            placeholder="Search Extensions..." 
            className="w-full bg-transparent py-1.5 px-2 text-[13px] text-white focus:outline-none placeholder:text-[#858585]"
          />
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto px-2 custom-scrollbar space-y-3 mt-2 pb-4">
        <ExtensionCard name="Prettier - Code formatter" author="Prettier" desc="Code formatter using prettier" installs="40M" />
        <ExtensionCard name="ESLint" author="Microsoft" desc="Integrates ESLint JavaScript into VS Code." installs="35M" />
        <ExtensionCard name="Python" author="Microsoft" desc="IntelliSense, Linting, Debugging." installs="100M" />
        <ExtensionCard name="GitLens — supercharged" author="GitKraken" desc="Supercharge Git within VS Code." installs="30M" />
      </div>
    </div>
  );
}

const ExtensionCard = ({ name, author, desc, installs }: { name: string, author: string, desc: string, installs: string }) => (
  <div className="flex gap-3 px-2 py-2 hover:bg-[#2a2d2e] rounded cursor-pointer group">
    <div className="w-10 h-10 bg-[#333] rounded flex items-center justify-center shrink-0">
      <Package size={20} className="text-[#858585]" />
    </div>
    <div className="flex-1 min-w-0">
      <div className="text-[13px] text-white font-medium truncate">{name}</div>
      <div className="text-[11px] text-[#cccccc] truncate">{desc}</div>
      <div className="flex items-center gap-3 text-[11px] text-[#858585] mt-1">
        <span>{author}</span>
        <span className="flex items-center gap-0.5"><Download size={10} /> {installs}</span>
        <span className="flex items-center gap-0.5"><Star size={10} /> 4.5</span>
      </div>
      <button className="mt-2 bg-blue-600 hover:bg-blue-500 text-white text-[11px] px-2 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity">Install</button>
    </div>
  </div>
);
