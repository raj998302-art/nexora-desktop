import React from 'react';
import { useUIStore } from '../store';
import { Explorer } from './Explorer';
import { SearchPanel } from './SearchPanel';
import { GitPanel } from './GitPanel';
import { ExtensionPanel } from './ExtensionPanel';

export const LeftPanel = () => {
  const { leftPanelMode } = useUIStore();

  return (
    <div className="flex w-64 bg-[#181818] border-r border-[#2b2b2b] h-full shrink-0 flex-col font-sans">
      <div className="px-5 py-2.5 text-[11px] font-semibold tracking-wide text-[#cccccc] uppercase shrink-0">
        {leftPanelMode === 'explorer' && 'Explorer'}
        {leftPanelMode === 'search' && 'Search'}
        {leftPanelMode === 'git' && 'Source Control'}
        {leftPanelMode === 'extensions' && 'Extensions'}
      </div>
      
      <div className="flex-1 overflow-hidden flex flex-col">
        {leftPanelMode === 'explorer' && <Explorer />}
        {leftPanelMode === 'search' && <SearchPanel />}
        {leftPanelMode === 'git' && <GitPanel />}
        {leftPanelMode === 'extensions' && <ExtensionPanel />}
      </div>
    </div>
  );
}
