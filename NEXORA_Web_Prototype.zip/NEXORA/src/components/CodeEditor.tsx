import React, { useState } from 'react';
import { X, MoreHorizontal, Lightbulb } from 'lucide-react';
import { cn } from '../utils/cn';

export const CodeEditor = () => {
  const [activeTab, setActiveTab] = useState<'app' | 'diff'>('app');
  const [hoverLine, setHoverLine] = useState<number | null>(null);

  const appCode = [
    { text: "import React from 'react';" },
    { text: "import { MainWorkspace } from './components/MainWorkspace';" },
    { text: "" },
    { text: "function App() {", isFunction: true, refs: "3 references" },
    { text: "  return (" },
    { text: "    <div className=\"flex h-screen w-screen bg-[#0a0a0a]\">" },
    { text: "      <ActivityBar />" },
    { text: "      <div className=\"flex flex-col flex-1 min-w-0\">" },
    { text: "        <MainWorkspace />" },
    { text: "        <StatusBar />" },
    { text: "      </div>" },
    { text: "    </div>" },
    { text: "  );" },
    { text: "}" },
    { text: "" },
    { text: "export default App;" }
  ];

  const diffCode = [
    { type: 'normal', text: "function App() {" },
    { type: 'normal', text: "  return (" },
    { type: 'removed', text: "    <div className=\"flex h-screen bg-[#0a0a0a]\">" },
    { type: 'added', text: "    <div className=\"flex flex-col h-screen w-screen bg-[#1e1e1e]\">" },
    { type: 'added', text: "      <TopBar />" },
    { type: 'normal', text: "      <ActivityBar />" },
    { type: 'normal', text: "      <div className=\"flex flex-col flex-1 min-w-0\">" },
    { type: 'normal', text: "        <MainWorkspace />" }
  ];

  return (
    <div className="flex-1 flex flex-col min-w-0 bg-[#1e1e1e]">
      {/* Tabs */}
      <div className="flex bg-[#181818] overflow-x-auto custom-scrollbar shrink-0">
        <Tab name="App.tsx" active={activeTab === 'app'} onClick={() => setActiveTab('app')} />
        <Tab name="App.tsx (Working Tree)" active={activeTab === 'diff'} onClick={() => setActiveTab('diff')} isDiff />
      </div>
      
      {/* Breadcrumbs */}
      <div className="h-6 flex items-center px-4 text-[#858585] text-xs font-sans border-b border-[#2b2b2b] bg-[#1e1e1e]">
        <span>src</span> <span className="mx-1">›</span> <span>App.tsx</span> {activeTab === 'diff' && <span className="text-yellow-500 ml-2">(Modified)</span>}
      </div>

      {/* Editor Surface */}
      <div className="flex-1 relative overflow-auto pt-2 pb-4 font-mono text-[13px] leading-[1.6] custom-scrollbar flex">
        
        {/* Main Code Area */}
        <div className="flex-1 overflow-x-auto">
          {activeTab === 'app' ? (
            <div className="flex relative">
              <div className="flex flex-col text-right pr-6 pl-4 text-[#858585] select-none shrink-0 border-r border-[#2b2b2b] mr-4 opacity-50 relative z-10 bg-[#1e1e1e]">
                {appCode.map((line, i) => (
                  <div key={i} className="flex flex-col">
                    {line.isFunction && <div className="h-[21px]"></div>}
                    <div 
                      className={hoverLine === i ? "text-[#cccccc]" : ""}
                      onMouseEnter={() => setHoverLine(i)}
                    >
                      {i + 1}
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Code Actions / Lightbulb Mock */}
              {hoverLine === 4 && (
                <div className="absolute left-[38px] top-[125px] z-20 text-yellow-400 cursor-pointer bg-[#1e1e1e] p-0.5" title="Quick Fix...">
                  <Lightbulb size={14} fill="currentColor" />
                </div>
              )}

              <div className="text-[#d4d4d4] min-w-max flex flex-col">
                {appCode.map((line, i) => (
                  <div key={i} className="flex flex-col">
                    {line.isFunction && (
                      <div className="text-[#858585] text-[11px] font-sans -mt-1 mb-1 cursor-pointer hover:text-[#cccccc] select-none">
                        {line.refs} | 1 author
                      </div>
                    )}
                    <div 
                      className="hover:bg-[#2a2d2e]/50 inline-block w-full whitespace-pre"
                      onMouseEnter={() => setHoverLine(i)}
                    >
                      {i === 0 && <span><span className="text-[#c586c0]">import</span> React <span className="text-[#c586c0]">from</span> <span className="text-[#ce9178]">'react'</span>;</span>}
                      {i === 1 && <span><span className="text-[#c586c0]">import</span> {'{'} MainWorkspace {'}'} <span className="text-[#c586c0]">from</span> <span className="text-[#ce9178]">'./components/MainWorkspace'</span>;</span>}
                      {i === 2 && <span></span>}
                      {i === 3 && <span><span className="text-[#569cd6]">function</span> <span className="text-[#dcdcaa]">App</span>() {'{'}</span>}
                      {i === 4 && <span>  <span className="text-[#c586c0]">return</span> (</span>}
                      {i === 5 && <span>    {'<'}<span className="text-[#569cd6]">div</span> <span className="text-[#9cdcfe]">className</span>=<span className="text-[#ce9178]">"flex h-screen bg-[#0a0a0a]"</span>{'>'}</span>}
                      {i === 6 && <span>      {'<'}<span className="text-[#4ec9b0]">ActivityBar</span> /{'>'}</span>}
                      {i === 7 && <span>      {'<'}<span className="text-[#569cd6]">div</span> <span className="text-[#9cdcfe]">className</span>=<span className="text-[#ce9178]">"flex-1 min-w-0"</span>{'>'}</span>}
                      {i === 8 && <span>        {'<'}<span className="text-[#4ec9b0]">MainWorkspace</span> /{'>'}</span>}
                      {i === 9 && <span>        {'<'}<span className="text-[#4ec9b0]">StatusBar</span> /{'>'}</span>}
                      {i === 10 && <span>      {'</'}<span className="text-[#569cd6]">div</span>{'>'}</span>}
                      {i === 11 && <span>    {'</'}<span className="text-[#569cd6]">div</span>{'>'}</span>}
                      {i === 12 && <span>  );</span>}
                      {i === 13 && <span>{'}'}</span>}
                      {i === 14 && <span></span>}
                      {i === 15 && <span><span className="text-[#c586c0]">export default</span> App;</span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex flex-col w-full min-w-max">
              {diffCode.map((line, i) => (
                <div key={i} className={cn(
                  "flex w-full",
                  line.type === 'removed' ? "bg-red-500/20" : line.type === 'added' ? "bg-green-500/20" : ""
                )}>
                  <div className="w-12 text-right pr-4 text-[#858585] select-none shrink-0 border-r border-[#2b2b2b] opacity-50">
                    {i + 1}
                  </div>
                  <div className="w-6 text-center select-none shrink-0">
                    {line.type === 'removed' ? <span className="text-red-400">-</span> : line.type === 'added' ? <span className="text-green-400">+</span> : ""}
                  </div>
                  <div className={cn("flex-1 pl-2 whitespace-pre pr-8", 
                    line.type === 'removed' ? "text-red-300" : line.type === 'added' ? "text-green-300" : "text-[#d4d4d4]"
                  )}>
                    {line.text}
                  </div>
                </div>
              ))}
              
              {activeTab === 'diff' && (
                <div className="sticky top-4 right-8 float-right bg-[#2a2d2e] border border-[#3c3c3c] rounded-md shadow-lg flex items-center p-1 font-sans mr-4 z-50">
                  <button className="px-3 py-1 text-xs text-white hover:bg-blue-600 rounded transition-colors mr-1">Accept</button>
                  <button className="px-3 py-1 text-xs text-[#cccccc] hover:bg-[#3c3c3c] rounded transition-colors mr-1">Reject</button>
                  <button className="px-2 py-1 text-[#858585] hover:text-white rounded transition-colors"><MoreHorizontal size={14} /></button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Minimap Mock */}
        {activeTab === 'app' && (
          <div className="w-16 bg-[#1e1e1e] border-l border-[#2b2b2b]/50 shrink-0 select-none overflow-hidden hidden md:block">
            <div className="w-full h-8 bg-[#333]/30 cursor-pointer hover:bg-[#333]/50 transition-colors"></div>
            <div className="pl-1 pt-1 opacity-20">
              <div className="w-8 h-px bg-[#c586c0] mb-1"></div>
              <div className="w-12 h-px bg-[#c586c0] mb-2"></div>
              <div className="w-6 h-px bg-[#569cd6] mb-1"></div>
              <div className="w-10 h-px bg-[#ce9178] mb-1 pl-2"></div>
              <div className="w-8 h-px bg-[#4ec9b0] mb-1 pl-4"></div>
              <div className="w-10 h-px bg-[#ce9178] mb-1 pl-4"></div>
              <div className="w-8 h-px bg-[#4ec9b0] mb-1 pl-6"></div>
              <div className="w-6 h-px bg-[#569cd6] mb-2 pl-2"></div>
              <div className="w-8 h-px bg-[#c586c0] mb-1"></div>
            </div>
          </div>
        )}
        
      </div>
    </div>
  );
}

const Tab = ({ name, active = false, onClick, isDiff = false }: { name: string, active?: boolean, onClick: () => void, isDiff?: boolean }) => (
  <div 
    onClick={onClick}
    className={`flex items-center gap-2 px-3 py-2 text-[13px] border-r border-[#2b2b2b] cursor-pointer whitespace-nowrap group ${active ? 'bg-[#1e1e1e] text-white border-t border-t-blue-500' : 'text-[#858585] hover:bg-[#1e1e1e] border-t border-t-transparent'}`}
  >
    <span className={isDiff ? "text-yellow-500 font-mono text-xs" : "text-[#519aba] font-mono text-xs"}>ts</span>
    <span className={active ? (isDiff ? "text-yellow-300" : "text-[#519aba]") : ""}>{name}</span>
    <X size={14} className={`opacity-0 group-hover:opacity-100 hover:bg-[#333] rounded p-0.5 ${active ? 'opacity-100' : ''}`} />
  </div>
);
