import React from 'react';
import { Sparkles, Save } from 'lucide-react';

export const AgentBuilder = () => {
  return (
    <div className="flex-1 p-8 max-w-4xl mx-auto w-full font-sans">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-semibold flex items-center gap-2 text-white">
            <Sparkles className="text-blue-400" />
            Configure Agent
          </h2>
          <p className="text-[#858585] mt-1 text-sm">Define custom AI behavior and tool permissions.</p>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-1.5 rounded border border-[#3c3c3c] text-[#cccccc] hover:text-white hover:bg-[#2a2d2e] transition text-sm">Discard</button>
          <button className="px-4 py-1.5 rounded bg-blue-600 text-white flex items-center gap-2 hover:bg-blue-500 transition text-sm">
            <Save size={14} />
            Save Agent
          </button>
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-[#181818] border border-[#2b2b2b] rounded-lg p-6 space-y-5 shadow-sm">
          <h3 className="font-medium text-white border-b border-[#2b2b2b] pb-2 text-sm">Identity & Model</h3>
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs text-[#858585] uppercase tracking-wider">Agent Name</label>
              <input type="text" className="w-full bg-[#1e1e1e] border border-[#3c3c3c] rounded p-2 text-sm focus:border-blue-500 outline-none text-[#cccccc] transition-colors" placeholder="e.g. Next.js Architect" />
            </div>
            <div className="space-y-2">
              <label className="text-xs text-[#858585] uppercase tracking-wider">Base Model</label>
              <select className="w-full bg-[#1e1e1e] border border-[#3c3c3c] rounded p-2 text-sm focus:border-blue-500 outline-none text-[#cccccc] transition-colors">
                <option>Claude 3.5 Sonnet</option>
                <option>GPT-4o</option>
                <option>Gemini 1.5 Pro</option>
              </select>
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs text-[#858585] uppercase tracking-wider">System Instructions</label>
            <textarea className="w-full h-32 bg-[#1e1e1e] border border-[#3c3c3c] rounded p-3 text-sm focus:border-blue-500 outline-none resize-none text-[#cccccc] transition-colors custom-scrollbar" placeholder="You are an expert developer..."></textarea>
          </div>
        </div>

        <div className="bg-[#181818] border border-[#2b2b2b] rounded-lg p-6 space-y-5 shadow-sm">
          <h3 className="font-medium text-white border-b border-[#2b2b2b] pb-2 text-sm">Tool Permissions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Checkbox label="Terminal Access" desc="Can execute bash commands" checked />
            <Checkbox label="File System" desc="Can read, create, and modify files" checked />
            <Checkbox label="Auto Approval" desc="Skip confirmation for standard edits" />
            <Checkbox label="Network Requests" desc="Can use curl/fetch to test APIs" />
          </div>
        </div>
      </div>
    </div>
  );
}

const Checkbox = ({ label, desc, checked = false }: { label: string, desc: string, checked?: boolean }) => {
  const [isChecked, setIsChecked] = React.useState(checked);
  return (
    <label className="flex items-start gap-3 p-3 border border-[#2b2b2b] rounded bg-[#1e1e1e] cursor-pointer hover:border-[#3c3c3c] transition-colors group">
      <div className={`mt-0.5 w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-colors ${isChecked ? 'bg-blue-600 border-blue-600' : 'border-[#555] group-hover:border-[#888]'}`}>
        {isChecked && <Sparkles size={10} className="text-white" />}
      </div>
      <input type="checkbox" className="hidden" checked={isChecked} onChange={() => setIsChecked(!isChecked)} />
      <div>
        <div className="font-medium text-sm text-[#cccccc] group-hover:text-white transition-colors">{label}</div>
        <div className="text-xs text-[#858585] mt-0.5">{desc}</div>
      </div>
    </label>
  );
}
