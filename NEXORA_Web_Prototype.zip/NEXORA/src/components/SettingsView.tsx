import React, { useState } from 'react';
import { User, Key, Palette, Keyboard, Shield, Blocks, Cpu, Monitor, Github } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '../utils/cn';

export const SettingsView = () => {
  const [activeTab, setActiveTab] = useState('general');

  return (
    <div className="flex h-full w-full bg-[#1e1e1e] font-sans text-sm text-[#cccccc]">
      
      {/* Settings Sidebar */}
      <div className="w-56 bg-[#181818] border-r border-[#2b2b2b] flex flex-col pt-6 px-3">
        <h2 className="px-3 text-lg font-semibold text-white mb-6">Settings</h2>
        
        <div className="space-y-1">
          <SettingsTab icon={<Monitor size={16}/>} label="General" active={activeTab==='general'} onClick={()=>setActiveTab('general')} />
          <SettingsTab icon={<Palette size={16}/>} label="Appearance" active={activeTab==='appearance'} onClick={()=>setActiveTab('appearance')} />
          <SettingsTab icon={<Cpu size={16}/>} label="AI & Models" active={activeTab==='models'} onClick={()=>setActiveTab('models')} />
          <SettingsTab icon={<Key size={16}/>} label="API Keys" active={activeTab==='apikeys'} onClick={()=>setActiveTab('apikeys')} />
          <SettingsTab icon={<Github size={16}/>} label="Integrations" active={activeTab==='integrations'} onClick={()=>setActiveTab('integrations')} />
          <SettingsTab icon={<Keyboard size={16}/>} label="Shortcuts" active={activeTab==='shortcuts'} onClick={()=>setActiveTab('shortcuts')} />
          <SettingsTab icon={<Blocks size={16}/>} label="Extensions" active={activeTab==='extensions'} onClick={()=>setActiveTab('extensions')} />
          <SettingsTab icon={<Shield size={16}/>} label="Privacy" active={activeTab==='privacy'} onClick={()=>setActiveTab('privacy')} />
        </div>
      </div>

      {/* Settings Content */}
      <div className="flex-1 overflow-y-auto p-10 custom-scrollbar">
        <div className="max-w-2xl mx-auto space-y-10">
          <AnimatePresence mode="wait">
            {activeTab === 'general' && (
              <motion.div key="general" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.15 }} className="space-y-8">
                <div>
                  <h3 className="text-xl font-medium text-white mb-1">General</h3>
                  <p className="text-[#858585] text-xs">Configure basic workspace behavior.</p>
                </div>
                
                <div className="space-y-6">
                  <SettingsToggle label="Auto Save" desc="Automatically save files after a delay." checked />
                  <SettingsToggle label="Format on Save" desc="Run Prettier or the default formatter when saving." checked />
                  
                  <div className="space-y-2">
                    <label className="text-white font-medium block">Default Terminal Shell</label>
                    <select className="w-full bg-[#2a2d2e] border border-[#3c3c3c] rounded p-2 text-sm focus:border-blue-500 outline-none text-[#cccccc]">
                      <option>bash</option>
                      <option>zsh</option>
                      <option>powershell</option>
                    </select>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'models' && (
              <motion.div key="models" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.15 }} className="space-y-8">
                <div>
                  <h3 className="text-xl font-medium text-white mb-1">AI & Models</h3>
                  <p className="text-[#858585] text-xs">Configure default models for Chat, Agent, and Autocomplete.</p>
                </div>
                
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-white font-medium block">Chat Model</label>
                    <select className="w-full bg-[#2a2d2e] border border-[#3c3c3c] rounded p-2 text-sm focus:border-blue-500 outline-none text-[#cccccc]">
                      <option>Claude 3.5 Sonnet</option>
                      <option>GPT-4o</option>
                      <option>Gemini 1.5 Pro</option>
                    </select>
                  </div>
                  <SettingsToggle label="Enable Inline Autocomplete" desc="Show ghost text suggestions as you type (Copilot-style)." checked />
                </div>
              </motion.div>
            )}

            {activeTab === 'apikeys' && (
              <motion.div key="apikeys" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.15 }} className="space-y-8">
                <div>
                  <h3 className="text-xl font-medium text-white mb-1">API Keys</h3>
                  <p className="text-[#858585] text-xs">Bring your own keys to bypass usage limits.</p>
                </div>
                
                <div className="space-y-6">
                  <ApiKeyInput name="OpenAI API Key" placeholder="sk-..." />
                  <ApiKeyInput name="Anthropic API Key" placeholder="sk-ant-..." />
                  <ApiKeyInput name="Google Gemini API Key" placeholder="AIza..." />
                </div>
              </motion.div>
            )}

            {activeTab === 'integrations' && (
              <motion.div key="integrations" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.15 }} className="space-y-8">
                <div>
                  <h3 className="text-xl font-medium text-white mb-1">Integrations</h3>
                  <p className="text-[#858585] text-xs">Connect external accounts and services.</p>
                </div>
                
                <div className="p-4 border border-[#3c3c3c] bg-[#2a2d2e] rounded-lg flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Github size={24} className="text-white" />
                    <div>
                      <div className="text-white font-medium">GitHub Connect</div>
                      <div className="text-[#858585] text-xs">Connect GitHub to index your repositories and PRs.</div>
                    </div>
                  </div>
                  <button className="px-4 py-1.5 bg-[#181818] border border-[#3c3c3c] hover:bg-[#333] hover:text-white transition-colors rounded text-sm">
                    Connect
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

const SettingsTab = ({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={cn(
      "w-full flex items-center gap-3 px-3 py-2 rounded-md transition-colors text-left",
      active ? "bg-[#37373d] text-white" : "text-[#cccccc] hover:bg-[#2a2d2e] hover:text-white"
    )}
  >
    <span className={active ? "text-blue-400" : "text-[#858585]"}>{icon}</span>
    <span>{label}</span>
  </button>
);

const SettingsToggle = ({ label, desc, checked = false }: { label: string, desc: string, checked?: boolean }) => {
  const [isChecked, setIsChecked] = useState(checked);
  return (
    <div className="flex items-center justify-between py-2 border-b border-[#2b2b2b]">
      <div>
        <div className="text-white font-medium">{label}</div>
        <div className="text-[#858585] text-xs mt-0.5">{desc}</div>
      </div>
      <button 
        onClick={() => setIsChecked(!isChecked)}
        className={cn("w-10 h-5 rounded-full relative transition-colors duration-200", isChecked ? "bg-blue-600" : "bg-[#3c3c3c]")}
      >
        <div className={cn("absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full transition-transform duration-200 shadow", isChecked ? "translate-x-5" : "translate-x-0")} />
      </button>
    </div>
  );
};

const ApiKeyInput = ({ name, placeholder }: { name: string, placeholder: string }) => (
  <div className="space-y-2">
    <label className="text-white font-medium block">{name}</label>
    <input 
      type="password" 
      placeholder={placeholder}
      className="w-full bg-[#1e1e1e] border border-[#3c3c3c] rounded p-2 text-sm focus:border-blue-500 outline-none font-mono text-white"
    />
  </div>
);
