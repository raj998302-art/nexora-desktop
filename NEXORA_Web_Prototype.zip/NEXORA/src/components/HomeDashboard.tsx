import React, { useState } from 'react';
import { Search, Plus, Folder, Terminal, Sparkles, Command, Brain, Globe, Check, Zap, AtSign, ChevronDown, MessageSquare } from 'lucide-react';
import { useUIStore } from '../store';
import { cn } from '../utils/cn';
import { motion, AnimatePresence } from 'framer-motion';

type AiMode = 'Normal' | 'Agent' | 'Architect';
type ThinkingLevel = 'Normal' | 'High' | 'Max' | 'Ultra';

export const HomeDashboard = () => {
  const setView = useUIStore(s => s.setView);
  const [mode, setMode] = useState<AiMode>('Normal');
  const [showModeDropdown, setShowModeDropdown] = useState(false);
  
  const [thinkingLevel, setThinkingLevel] = useState<ThinkingLevel>('Normal');
  const [showThinkingDropdown, setShowThinkingDropdown] = useState(false);
  
  const [webSearch, setWebSearch] = useState(false);

  return (
    <div className="flex flex-col items-center justify-center h-full w-full bg-[#1e1e1e] text-[#cccccc] p-6 relative font-sans">
      
      <div className="w-full max-w-2xl flex flex-col items-center mt-[-10vh]">
        
        {/* Subtle Logo/Title */}
        <div className="flex items-center gap-3 mb-10 opacity-90">
          <Sparkles className="text-blue-400 w-8 h-8" />
          <h1 className="text-3xl font-semibold tracking-wide text-white">NEXORA</h1>
        </div>

        {/* Central Composer Input */}
        <div className="w-full relative group">
          <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-xl blur opacity-30 group-hover:opacity-60 transition duration-500"></div>
          
          <div className="relative flex flex-col bg-[#252526] border border-[#3c3c3c] rounded-xl shadow-2xl focus-within:border-[#555] transition-colors overflow-visible">
            
            <textarea 
              placeholder={mode === 'Agent' ? "Tell NEXORA what to build... (⌘K)" : "Ask a question..."}
              className="w-full bg-transparent pt-5 px-5 text-base text-white focus:outline-none placeholder:text-[#858585] resize-none h-24 custom-scrollbar"
              autoFocus
            />
            
            {/* Bottom Actions inside Input */}
            <div className="flex justify-between items-center px-4 pb-3 pt-2">
              <div className="flex items-center gap-1.5 relative">
                
                {/* Mode Selector Dropdown */}
                <div className="relative">
                  <button 
                    onClick={() => { setShowModeDropdown(!showModeDropdown); setShowThinkingDropdown(false); }}
                    className={cn(
                      "flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors border",
                      mode === 'Agent' || mode === 'Architect' ? "bg-blue-500/10 border-blue-500/30 text-blue-400" : "bg-[#3c3c3c]/50 border-transparent text-[#cccccc] hover:bg-[#3c3c3c]"
                    )}
                  >
                    {mode === 'Normal' && <MessageSquare size={14} />}
                    {mode === 'Agent' && <Zap size={14} />}
                    {mode === 'Architect' && <Check size={14} />}
                    <span>{mode}</span>
                    <ChevronDown size={12} className="opacity-70" />
                  </button>
                  
                  <AnimatePresence>
                    {showModeDropdown && (
                      <motion.div 
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 5 }}
                        transition={{ duration: 0.15 }}
                        className="absolute bottom-full left-0 mb-2 w-48 bg-[#252526] border border-[#3c3c3c] rounded-lg shadow-xl p-1 z-50 flex flex-col"
                      >
                        <DropdownOption icon={<MessageSquare size={14} />} title="Normal" desc="Standard AI chat assistant" active={mode === 'Normal'} onClick={() => { setMode('Normal'); setShowModeDropdown(false); }} />
                        <DropdownOption icon={<Zap size={14} />} title="Agent" desc="Autonomous code execution" active={mode === 'Agent'} onClick={() => { setMode('Agent'); setShowModeDropdown(false); }} />
                        <DropdownOption icon={<Check size={14} />} title="Architect" desc="Multi-file planning & review" active={mode === 'Architect'} onClick={() => { setMode('Architect'); setShowModeDropdown(false); }} />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="h-4 w-px bg-[#3c3c3c] mx-1"></div>

                <button className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors text-[#858585] hover:bg-[#333] hover:text-[#cccccc]" title="Add Context (@)">
                  <AtSign size={14} />
                  <span>Context</span>
                </button>

                {/* Thinking Level Dropdown */}
                <div className="relative">
                  <button 
                    onClick={() => { setShowThinkingDropdown(!showThinkingDropdown); setShowModeDropdown(false); }}
                    className={cn(
                      "flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors border",
                      thinkingLevel !== 'Normal' ? "bg-purple-500/10 border-purple-500/30 text-purple-400" : "bg-transparent border-transparent text-[#858585] hover:bg-[#333] hover:text-[#cccccc]"
                    )}
                    title="Deep Reasoning Mode"
                  >
                    <Brain size={14} />
                    <span>{thinkingLevel === 'Normal' ? 'Thinking' : thinkingLevel}</span>
                    <ChevronDown size={12} className="opacity-70" />
                  </button>

                  <AnimatePresence>
                    {showThinkingDropdown && (
                      <motion.div 
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 5 }}
                        transition={{ duration: 0.15 }}
                        className="absolute bottom-full left-0 mb-2 w-48 bg-[#252526] border border-[#3c3c3c] rounded-lg shadow-xl p-1 z-50 flex flex-col"
                      >
                        <DropdownOption icon={<Brain size={14} />} title="Normal" desc="Standard reasoning" active={thinkingLevel === 'Normal'} onClick={() => { setThinkingLevel('Normal'); setShowThinkingDropdown(false); }} />
                        <DropdownOption icon={<Brain size={14} />} title="High" desc="Extended chain of thought" active={thinkingLevel === 'High'} onClick={() => { setThinkingLevel('High'); setShowThinkingDropdown(false); }} />
                        <DropdownOption icon={<Brain size={14} />} title="Max" desc="Deep problem solving" active={thinkingLevel === 'Max'} onClick={() => { setThinkingLevel('Max'); setShowThinkingDropdown(false); }} />
                        <DropdownOption icon={<Brain size={14} />} title="Ultra" desc="Maximum compute limits" active={thinkingLevel === 'Ultra'} onClick={() => { setThinkingLevel('Ultra'); setShowThinkingDropdown(false); }} />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <button 
                  onClick={() => setWebSearch(!webSearch)}
                  className={cn("flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors border", webSearch ? "bg-green-500/10 border-green-500/30 text-green-400" : "bg-transparent border-transparent text-[#858585] hover:bg-[#333] hover:text-[#cccccc]")}
                  title="Search the web"
                >
                  <Globe size={14} />
                  <span>Web</span>
                </button>
              </div>
              
              <div className="flex items-center gap-3">
                <kbd className="hidden sm:flex px-2 py-1 bg-[#1e1e1e] border border-[#3c3c3c] rounded text-xs font-mono text-[#858585] items-center gap-1">
                  <Command size={10}/> Enter
                </kbd>
                <button className="flex items-center justify-center p-2 text-white transition rounded-md bg-blue-600 hover:bg-blue-500 shadow-md">
                  <Sparkles size={16} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Shortcuts / Quick Actions */}
        <div className="flex flex-wrap items-center justify-center gap-6 mt-8 text-sm text-[#858585]">
          <ActionShortcut icon={<Plus size={16} />} label="New Project" shortcut="⌘ N" onClick={() => setView('editor')} />
          <ActionShortcut icon={<Folder size={16} />} label="Open Workspace" shortcut="⌘ O" onClick={() => setView('editor')} />
          <ActionShortcut icon={<Terminal size={16} />} label="Terminal" shortcut="⌘ J" />
          <ActionShortcut icon={<Search size={16} />} label="Search Files" shortcut="⇧ ⌘ F" />
        </div>
      </div>

      {/* Recent Projects - Minimal List at bottom */}
      <div className="absolute bottom-12 w-full max-w-xl mx-auto opacity-70 hover:opacity-100 transition-opacity">
        <h3 className="text-xs font-bold tracking-widest text-[#858585] mb-3 uppercase text-center">Recent Workspaces</h3>
        <div className="grid grid-cols-2 gap-3">
          <RecentItem name="NEXORA UI" path="~/Projects/NEXORA" time="Just now" />
          <RecentItem name="AI Platform" path="~/Projects/ai-platform" time="Yesterday" />
          <RecentItem name="Flutter App" path="~/Projects/flutter-app" time="3 days ago" />
          <RecentItem name="API Gateway" path="~/Projects/api-gateway" time="Last week" />
        </div>
      </div>
    </div>
  );
}

const DropdownOption = ({ icon, title, desc, active, onClick }: { icon: React.ReactNode, title: string, desc: string, active: boolean, onClick: () => void }) => (
  <div 
    onClick={onClick}
    className={cn(
      "flex flex-col px-3 py-2 rounded-md cursor-pointer transition-colors",
      active ? "bg-blue-500/10" : "hover:bg-[#37373d]"
    )}
  >
    <div className={cn("flex items-center gap-2 text-sm font-medium", active ? "text-blue-400" : "text-[#cccccc]")}>
      {icon}
      <span>{title}</span>
    </div>
    <span className="text-[10px] text-[#858585] ml-6 mt-0.5">{desc}</span>
  </div>
);

const ActionShortcut = ({ icon, label, shortcut, onClick }: { icon: React.ReactNode, label: string, shortcut: string, onClick?: () => void }) => (
  <button onClick={onClick} className="flex items-center gap-2 hover:text-white transition-colors group cursor-pointer">
    <span className="text-[#858585] group-hover:text-[#cccccc]">{icon}</span>
    <span>{label}</span>
    <kbd className="ml-1 text-xs px-1.5 py-0.5 rounded bg-[#2a2d2e] text-[#858585] group-hover:text-[#cccccc] font-mono border border-[#3c3c3c]">{shortcut}</kbd>
  </button>
);

const RecentItem = ({ name, path, time }: { name: string, path: string, time: string }) => (
  <div className="flex flex-col p-3 rounded-lg border border-transparent hover:border-[#3c3c3c] hover:bg-[#252526] transition-all cursor-pointer">
    <div className="flex items-center justify-between mb-1">
      <span className="text-sm font-medium text-white">{name}</span>
      <span className="text-xs text-[#858585]">{time}</span>
    </div>
    <span className="text-xs text-[#858585] truncate">{path}</span>
  </div>
);
