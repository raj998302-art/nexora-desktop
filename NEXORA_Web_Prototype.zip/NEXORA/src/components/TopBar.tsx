import React, { useState } from 'react';
import { Search, Play, Square, Layout, Menu, Bell, Moon, Sun } from 'lucide-react';
import { useUIStore } from '../store';

export const TopBar = () => {
  const { agentRunning, setAgentRunning } = useUIStore();
  const [darkTheme, setDarkTheme] = useState(true);

  return (
    <div className="h-9 bg-[#181818] border-b border-[#2b2b2b] flex items-center justify-between px-3 shrink-0 text-xs text-[#cccccc] select-none z-30 drag-region">
      {/* Left: Window Controls / Menus */}
      <div className="flex items-center gap-4 no-drag">
        <Menu size={14} className="cursor-pointer hover:text-white" />
        <div className="flex gap-3">
          <span className="cursor-pointer hover:text-white">File</span>
          <span className="cursor-pointer hover:text-white">Edit</span>
          <span className="cursor-pointer hover:text-white">Selection</span>
          <span className="cursor-pointer hover:text-white">View</span>
          <span className="cursor-pointer hover:text-white">Go</span>
          <span className="cursor-pointer hover:text-white">Run</span>
          <span className="cursor-pointer hover:text-white">Terminal</span>
          <span className="cursor-pointer hover:text-white">Help</span>
        </div>
      </div>

      {/* Center: Command Palette / Search */}
      <div className="flex-1 max-w-lg mx-auto flex items-center justify-center no-drag">
        <div className="flex items-center bg-[#2a2d2e] border border-[#3c3c3c] rounded-md px-3 py-1 w-full max-w-sm gap-2 hover:bg-[#333] cursor-pointer transition-colors">
          <Search size={12} className="text-[#858585]" />
          <span className="text-[#858585] flex-1 text-center font-medium">NEXORA (⌘K)</span>
        </div>
      </div>

      {/* Right: AI Actions & Layout */}
      <div className="flex items-center gap-3 no-drag">
        <button onClick={() => setDarkTheme(!darkTheme)} className="text-[#858585] hover:text-white transition-colors" title="Toggle Theme">
          {darkTheme ? <Sun size={14} /> : <Moon size={14} />}
        </button>
        <button className="text-[#858585] hover:text-white transition-colors relative" title="Notifications">
          <Bell size={14} />
          <div className="absolute -top-1 -right-1 w-2 h-2 bg-blue-500 rounded-full"></div>
        </button>
        <div className="h-4 w-px bg-[#3c3c3c] mx-1"></div>
        {agentRunning ? (
          <button onClick={() => setAgentRunning(false)} className="flex items-center gap-1.5 text-red-400 hover:text-red-300 transition-colors bg-red-500/10 px-2 py-0.5 rounded border border-red-500/20">
            <Square size={10} fill="currentColor" />
            <span>Stop</span>
          </button>
        ) : (
          <button onClick={() => setAgentRunning(true)} className="flex items-center gap-1.5 text-blue-400 hover:text-blue-300 transition-colors bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
            <Play size={10} fill="currentColor" />
            <span>Agent</span>
          </button>
        )}
        <div className="h-4 w-px bg-[#3c3c3c] mx-1"></div>
        <Layout size={14} className="cursor-pointer hover:text-white text-[#858585]" title="Panel Layout" />
      </div>
    </div>
  );
}
