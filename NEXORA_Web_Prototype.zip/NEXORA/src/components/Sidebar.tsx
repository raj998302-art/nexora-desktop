import React from 'react';
import { Home, Folder, MessageSquare, Terminal, Settings, LayoutGrid, Package, ChevronLeft, ChevronRight, Activity } from 'lucide-react';
import { cn } from '../utils/cn';
import { useUIStore } from '../store';

export const Sidebar = ({ isOpen, toggle }: { isOpen: boolean; toggle: () => void }) => {
  const { view, setView } = useUIStore();

  return (
    <div className={cn(
      "flex flex-col bg-nexora-800 border-r border-nexora-700 transition-all duration-300 ease-in-out relative z-20 shrink-0",
      isOpen ? "w-64" : "w-16"
    )}>
      {/* Logo Area */}
      <div className="h-12 flex items-center justify-center border-b border-nexora-700 shrink-0">
        <div className="flex items-center gap-2 font-bold tracking-widest text-lg">
          <div className="relative flex items-center justify-center w-8 h-8">
            <div className="absolute inset-0 bg-nexora-accent opacity-20 rounded-full blur-md"></div>
            <Activity className="w-5 h-5 text-nexora-glow z-10" />
          </div>
          {isOpen && <span className="text-white">NEXORA</span>}
        </div>
      </div>

      {/* Nav Items */}
      <div className="flex-1 py-4 flex flex-col gap-2 px-2 overflow-y-auto">
        <NavItem icon={<Home size={18} />} label="Home" isOpen={isOpen} active={view === 'home'} onClick={() => setView('home')} />
        <NavItem icon={<Folder size={18} />} label="Editor" isOpen={isOpen} active={view === 'editor'} onClick={() => setView('editor')} />
        <NavItem icon={<LayoutGrid size={18} />} label="Agent Builder" isOpen={isOpen} active={view === 'agent-builder'} onClick={() => setView('agent-builder')} />
        <NavItem icon={<Package size={18} />} label="Extensions" isOpen={isOpen} />
      </div>

      {/* Bottom Actions */}
      <div className="p-2 border-t border-nexora-700 flex flex-col gap-2 shrink-0">
        <NavItem icon={<Settings size={18} />} label="Settings" isOpen={isOpen} />
        <button 
          onClick={toggle}
          className="flex items-center justify-center w-full p-2 text-nexora-400 hover:text-nexora-100 hover:bg-nexora-700 rounded-md transition-colors"
        >
          {isOpen ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}
        </button>
      </div>
    </div>
  );
}

const NavItem = ({ icon, label, isOpen, active, onClick }: { icon: React.ReactNode, label: string, isOpen: boolean, active?: boolean, onClick?: () => void }) => {
  return (
    <button onClick={onClick} className={cn(
      "flex items-center gap-3 p-2 rounded-md transition-colors w-full shrink-0",
      active ? "bg-nexora-accent/10 text-nexora-glow border border-nexora-accent/20" : "text-nexora-300 hover:bg-nexora-700 hover:text-nexora-100",
      !isOpen && "justify-center"
    )} title={label}>
      {icon}
      {isOpen && <span className="text-sm font-medium">{label}</span>}
    </button>
  );
}
