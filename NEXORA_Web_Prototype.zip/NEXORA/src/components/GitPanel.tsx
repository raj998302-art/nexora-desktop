import React from 'react';
import { Plus, Check, ChevronDown } from 'lucide-react';

export const GitPanel = () => {
  return (
    <div className="flex flex-col h-full font-sans">
      <div className="px-3 pb-3 pt-1">
        <div className="bg-[#2a2d2e] border border-[#3c3c3c] rounded flex flex-col focus-within:border-blue-500 transition-colors">
          <textarea 
            placeholder="Message (⌘Enter to commit)" 
            className="w-full bg-transparent py-1.5 px-2 text-[13px] focus:outline-none resize-none h-16 text-white custom-scrollbar placeholder:text-[#858585]"
          />
        </div>
        <button className="w-full mt-2 bg-blue-600 hover:bg-blue-500 rounded py-1 text-[13px] transition text-white font-medium flex items-center justify-center gap-2">
          Commit
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto px-2 mt-2">
        <div className="px-2 py-1 text-[11px] font-semibold text-[#cccccc] flex justify-between group cursor-pointer hover:bg-[#2a2d2e]">
          <div className="flex items-center gap-1">
            <ChevronDown size={14} />
            CHANGES <span className="bg-[#333] rounded-full px-1.5 text-[10px] ml-1">3</span>
          </div>
          <div className="flex gap-1 opacity-0 group-hover:opacity-100">
            <Plus size={14} className="hover:text-white" title="Stage All Changes" />
            <Check size={14} className="hover:text-white" title="Commit Staged" />
          </div>
        </div>
        <div className="space-y-0.5 mt-1">
          <GitFile name="App.tsx" path="src" status="M" />
          <GitFile name="MainWorkspace.tsx" path="src/components" status="M" />
          <GitFile name="LeftPanel.tsx" path="src/components" status="U" />
        </div>
      </div>
    </div>
  );
}

const GitFile = ({ name, path, status }: { name: string, path: string, status: string }) => (
  <div className="flex items-center justify-between pl-6 pr-2 py-1 hover:bg-[#2a2d2e] rounded cursor-pointer text-[13px] group">
    <div className="flex items-center gap-2 truncate">
      <span className="text-[#cccccc] truncate">{name}</span>
      <span className="text-[#858585] text-[11px] truncate">{path}</span>
    </div>
    <div className="flex items-center gap-2 shrink-0">
      <Plus size={14} className="text-[#858585] hover:text-white opacity-0 group-hover:opacity-100" />
      <span className={`text-[11px] font-bold ${status === 'U' ? 'text-green-400' : 'text-blue-400'}`}>{status}</span>
    </div>
  </div>
);
