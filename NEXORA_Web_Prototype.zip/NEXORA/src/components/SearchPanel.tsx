import React from 'react';
import { ChevronRight, Search, Replace, CaseSensitive, WholeWord, Regex } from 'lucide-react';

export const SearchPanel = () => {
  return (
    <div className="flex flex-col h-full p-2">
      <div className="flex flex-col gap-2 relative">
        <div className="relative flex items-center border border-[#3c3c3c] bg-[#2a2d2e] rounded focus-within:border-blue-500 transition-colors">
          <ChevronRight size={14} className="text-[#858585] ml-1" />
          <input 
            type="text" 
            placeholder="Search" 
            className="w-full bg-transparent py-1 px-1.5 text-[13px] text-white focus:outline-none placeholder:text-[#858585]"
          />
          <div className="flex items-center gap-1 pr-1">
            <button className="p-0.5 hover:bg-[#333] rounded text-[#858585] hover:text-white"><CaseSensitive size={14} /></button>
            <button className="p-0.5 hover:bg-[#333] rounded text-[#858585] hover:text-white"><WholeWord size={14} /></button>
            <button className="p-0.5 hover:bg-[#333] rounded text-[#858585] hover:text-white"><Regex size={14} /></button>
          </div>
        </div>
        
        <div className="relative flex items-center border border-[#3c3c3c] bg-[#2a2d2e] rounded focus-within:border-blue-500 transition-colors ml-4">
          <input 
            type="text" 
            placeholder="Replace" 
            className="w-full bg-transparent py-1 px-1.5 text-[13px] text-white focus:outline-none placeholder:text-[#858585]"
          />
          <div className="flex items-center gap-1 pr-1">
            <button className="p-0.5 hover:bg-[#333] rounded text-[#858585] hover:text-white"><Replace size={14} /></button>
          </div>
        </div>
      </div>
      
      <div className="mt-4 text-[#cccccc] text-xs px-2 flex flex-col gap-2">
        <div className="font-semibold text-[#858585]">0 results in 0 files</div>
      </div>
    </div>
  );
}
