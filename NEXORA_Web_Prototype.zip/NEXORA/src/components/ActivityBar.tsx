import React, { useState } from 'react';
import { Files, Search, GitBranch, Settings, Package, Sparkles, User, LogOut, CreditCard, Home, Github, Plug } from 'lucide-react';
import { useUIStore } from '../store';
import { cn } from '../utils/cn';
import { motion, AnimatePresence } from 'framer-motion';

export const ActivityBar = () => {
  const { leftPanelMode, setLeftPanelMode, view, setView } = useUIStore();
  const [showProfile, setShowProfile] = useState(false);

  return (
    <div className="w-12 bg-[#181818] border-r border-[#2b2b2b] flex flex-col items-center py-3 justify-between shrink-0 z-20 relative">
      <div className="flex flex-col gap-4 items-center w-full">
        <ActivityIcon 
          icon={<Home size={24} strokeWidth={1.2} />} 
          active={view === 'home'} 
          onClick={() => setView('home')} 
          title="Home Dashboard"
        />

        <div className="w-8 h-px bg-[#2b2b2b] my-1"></div>

        <ActivityIcon 
          icon={<Files size={24} strokeWidth={1.2} />} 
          active={leftPanelMode === 'explorer' && view !== 'home' && view !== 'settings'} 
          onClick={() => { setLeftPanelMode('explorer'); setView('editor'); }} 
          title="Explorer (⇧⌘E)"
        />
        <ActivityIcon 
          icon={<Search size={24} strokeWidth={1.2} />} 
          active={leftPanelMode === 'search' && view !== 'home' && view !== 'settings'} 
          onClick={() => { setLeftPanelMode('search'); setView('editor'); }} 
          title="Search (⇧⌘F)"
        />
        <ActivityIcon 
          icon={<GitBranch size={24} strokeWidth={1.2} />} 
          active={leftPanelMode === 'git' && view !== 'home' && view !== 'settings'} 
          onClick={() => { setLeftPanelMode('git'); setView('editor'); }} 
          title="Source Control (⌃⇧G)"
        />
        <ActivityIcon 
          icon={<Package size={24} strokeWidth={1.2} />} 
          active={leftPanelMode === 'extensions' && view !== 'home' && view !== 'settings'} 
          onClick={() => { setLeftPanelMode('extensions'); setView('editor'); }} 
          title="Extensions (⇧⌘X)" 
        />
      </div>

      <div className="flex flex-col gap-4 items-center w-full relative">
        <ActivityIcon 
          icon={<Github size={24} strokeWidth={1.2} />} 
          active={false} 
          onClick={() => {}} 
          title="Connect GitHub" 
        />
        <ActivityIcon 
          icon={<User size={24} strokeWidth={1.2} />} 
          active={showProfile} 
          onClick={() => setShowProfile(!showProfile)} 
          title="Accounts" 
        />
        <ActivityIcon 
          icon={<Settings size={24} strokeWidth={1.2} />} 
          active={view === 'settings'} 
          onClick={() => setView('settings')} 
          title="Settings (⌘,)" 
        />
        
        <AnimatePresence>
          {showProfile && (
            <motion.div 
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.15 }}
              className="absolute left-14 bottom-10 w-64 bg-[#1e1e1e] border border-[#3c3c3c] rounded-md shadow-2xl py-2 flex flex-col font-sans"
            >
              <div className="px-4 py-3 border-b border-[#2b2b2b]">
                <div className="text-white font-medium">user@nexora.ai</div>
                <div className="text-[#858585] text-xs mt-1">Pro Plan Active</div>
              </div>
              <button className="flex items-center gap-2 px-4 py-2 mt-2 text-sm text-[#cccccc] hover:bg-[#2a2d2e] hover:text-white transition-colors">
                <CreditCard size={14} /> Manage Subscription
              </button>
              <button className="flex items-center gap-2 px-4 py-2 text-sm text-[#cccccc] hover:bg-[#2a2d2e] hover:text-white transition-colors">
                <Plug size={14} /> Integrations & Keys
              </button>
              <button className="flex items-center gap-2 px-4 py-2 text-sm text-[#cccccc] hover:bg-[#2a2d2e] hover:text-white transition-colors" onClick={() => { setShowProfile(false); setView('settings'); }}>
                <Settings size={14} /> Settings
              </button>
              <div className="my-1 border-t border-[#2b2b2b]"></div>
              <button className="flex items-center gap-2 px-4 py-2 text-sm text-red-400 hover:bg-[#2a2d2e] hover:text-red-300 transition-colors">
                <LogOut size={14} /> Sign Out
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

const ActivityIcon = ({ icon, active, onClick, title }: { icon: React.ReactNode, active: boolean, onClick: () => void, title: string }) => (
  <div 
    onClick={onClick}
    title={title}
    className={cn(
      "w-full flex justify-center py-2 cursor-pointer transition-colors relative group",
      active ? "text-white" : "text-[#858585] hover:text-white"
    )}
  >
    {active && <div className="absolute left-0 top-0 bottom-0 w-[2px] bg-blue-500" />}
    {icon}
  </div>
);
