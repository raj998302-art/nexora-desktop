import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useUIStore } from '../store';
import { Loader2, Check, Circle, X } from 'lucide-react';

export const AgentRunner = () => {
  const { agentRunning, setAgentRunning } = useUIStore();
  const [steps, setSteps] = useState([
    { id: 1, text: 'Inspecting project files', status: 'pending' },
    { id: 2, text: 'Analyzing codebase structure', status: 'pending' },
    { id: 3, text: 'Executing modifications', status: 'pending' },
    { id: 4, text: 'Running local verification', status: 'pending' },
  ]);

  useEffect(() => {
    if (!agentRunning) {
      setSteps(steps.map(s => ({ ...s, status: 'pending' })));
      return;
    }

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep >= steps.length) {
        clearInterval(interval);
        return;
      }
      setSteps(prev => prev.map((s, i) => {
        if (i < currentStep) return { ...s, status: 'complete' };
        if (i === currentStep) return { ...s, status: 'running' };
        return s;
      }));
      currentStep++;
    }, 1500);

    return () => clearInterval(interval);
  }, [agentRunning]);

  return (
    <AnimatePresence>
      {agentRunning && (
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.98 }}
          transition={{ duration: 0.2 }}
          className="fixed bottom-12 right-6 w-80 bg-[#1e1e1e] border border-[#2b2b2b] rounded-lg shadow-2xl p-4 z-50 overflow-hidden font-sans"
        >
          <div className="flex items-center justify-between mb-3 border-b border-[#2b2b2b] pb-2">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-[#858585] uppercase tracking-wider">Background Task</span>
              <span className="text-sm font-medium text-[#cccccc]">Cursor Agent Running</span>
            </div>
            <button onClick={() => setAgentRunning(false)} className="text-[#858585] hover:text-white p-1 rounded hover:bg-[#2a2d2e] transition-colors">
              <X size={14} />
            </button>
          </div>

          <div className="space-y-2 mt-2">
            {steps.map(step => (
              <div key={step.id} className="flex items-center gap-2.5 text-[13px]">
                {step.status === 'complete' && <Check size={14} className="text-blue-500" />}
                {step.status === 'running' && <Loader2 size={14} className="text-[#cccccc] animate-spin" />}
                {step.status === 'pending' && <Circle size={14} className="text-[#333]" />}
                <span className={step.status === 'pending' ? 'text-[#858585]' : step.status === 'running' ? 'text-white' : 'text-[#cccccc]'}>
                  {step.text}
                </span>
              </div>
            ))}
          </div>
          
          {steps[steps.length - 1].status !== 'complete' && (
            <div className="mt-4 pt-3 border-t border-[#2b2b2b] flex justify-end">
               <button onClick={() => setAgentRunning(false)} className="px-3 py-1 text-xs bg-[#2a2d2e] hover:bg-[#333] border border-[#3c3c3c] rounded text-[#cccccc] transition-colors">
                 Cancel Task
               </button>
            </div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
