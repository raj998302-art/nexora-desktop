import React from 'react';
import { LeftPanel } from './LeftPanel';
import { CodeEditor } from './CodeEditor';
import { TerminalPane } from './TerminalPane';
import { AiChat } from './AiChat';
import { HomeDashboard } from './HomeDashboard';
import { SettingsView } from './SettingsView';
import { useUIStore } from '../store';
import { motion, AnimatePresence } from 'framer-motion';

export const MainWorkspace = () => {
  const view = useUIStore(s => s.view);

  return (
    <AnimatePresence mode="wait">
      {view === 'home' && (
        <motion.div 
          key="home"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="flex-1 overflow-auto bg-[#1e1e1e] relative"
        >
          <HomeDashboard />
        </motion.div>
      )}

      {view === 'settings' && (
        <motion.div 
          key="settings"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="flex-1 overflow-auto bg-[#1e1e1e] relative"
        >
          <SettingsView />
        </motion.div>
      )}

      {view === 'editor' && (
        <motion.div 
          key="editor"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="flex w-full h-full bg-[#1e1e1e]"
        >
          {/* Secondary Sidebar (Explorer) */}
          <LeftPanel />
          
          {/* Main Editor + Terminal */}
          <div className="flex flex-col flex-1 min-w-0 relative">
            <CodeEditor />
            <TerminalPane />
          </div>
          
          {/* AI Chat / Composer */}
          <div className="w-[350px] border-l border-[#2b2b2b] bg-[#181818] flex flex-col shrink-0 shadow-lg">
            <div className="flex-1 overflow-hidden relative">
              <AiChat />
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
