import React from 'react';
import { ActivityBar } from './components/ActivityBar';
import { MainWorkspace } from './components/MainWorkspace';
import { StatusBar } from './components/StatusBar';
import { AgentRunner } from './components/AgentRunner';
import { TopBar } from './components/TopBar';

function App() {
  return (
    <div className="flex flex-col h-screen w-screen bg-[#1e1e1e] text-[#cccccc] overflow-hidden font-sans selection:bg-[#264f78] selection:text-white">
      {/* Title Bar / Top Bar */}
      <TopBar />

      <div className="flex flex-1 min-h-0 relative">
        {/* Far Left: Activity Bar (Icons only) */}
        <ActivityBar />
        
        {/* Rest of the application */}
        <div className="flex flex-col flex-1 min-w-0 relative">
          <div className="flex-1 relative overflow-hidden flex">
            <MainWorkspace />
          </div>
        </div>
      </div>
      
      {/* Bottom: Status Bar */}
      <StatusBar />
      
      <AgentRunner />
    </div>
  );
}

export default App;
