import { create } from 'zustand';

interface UIState {
  view: 'home' | 'editor' | 'agent-builder' | 'settings';
  setView: (view: 'home' | 'editor' | 'agent-builder' | 'settings') => void;
  sidebarOpen: boolean;
  setSidebarOpen: (isOpen: boolean) => void;
  agentRunning: boolean;
  setAgentRunning: (running: boolean) => void;
  leftPanelMode: 'explorer' | 'search' | 'git' | 'extensions';
  setLeftPanelMode: (mode: 'explorer' | 'search' | 'git' | 'extensions') => void;
}

export const useUIStore = create<UIState>((set) => ({
  view: 'home',
  setView: (view) => set({ view }),
  sidebarOpen: true,
  setSidebarOpen: (isOpen) => set({ sidebarOpen: isOpen }),
  agentRunning: false,
  setAgentRunning: (running) => set({ agentRunning: running }),
  leftPanelMode: 'explorer',
  setLeftPanelMode: (mode) => set({ leftPanelMode: mode }),
}));
