/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        nexora: {
          900: '#0a0a0f',
          800: '#13131a',
          700: '#1c1c26',
          600: '#2b2b3a',
          500: '#3f3f54',
          400: '#5c5c77',
          300: '#8b8ba3',
          200: '#c4c4d4',
          100: '#e6e6f0',
          accent: '#4f46e5', // Indigo-like accent
          glow: '#818cf8',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['Fira Code', 'monospace'],
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      }
    },
  },
  plugins: [],
}
